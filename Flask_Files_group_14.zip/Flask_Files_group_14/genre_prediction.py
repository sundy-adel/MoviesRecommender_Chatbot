#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer


# In[2]:


data = pd.read_csv("C:/Users/HUSSIEN/Downloads/merged.csv")


# In[11]:


def build_chart(genre, percentile=0.85):

    full_text_lower = genre.lower()
    matching_titles = data[data['genres'].apply(lambda title: len(title) >= 3 and title.lower() in full_text_lower)]
    matching_titles_list = matching_titles['genres'].tolist()
    for title in matching_titles_list:
        new_title = title

    df = data[data['genres'] == new_title]
    vote_counts = df[df['vote_count'].notnull()]['vote_count'].astype('int')
    vote_averages = df[df['vote_average'].notnull()]['vote_average'].astype('int')
    C = vote_averages.mean()
    m = vote_counts.quantile(percentile)

    qualified = df[(df['vote_count'] >= m) & (df['vote_count'].notnull()) & (df['vote_average'].notnull())][['title', 'vote_count', 'vote_average', 'popularity']]
    qualified['vote_count'] = qualified['vote_count'].astype('int')
    qualified['vote_average'] = qualified['vote_average'].astype('int')

    qualified['wr'] = qualified.apply(lambda x: (x['vote_count']/(x['vote_count']+m) * x['vote_average']) + (m/(m+x['vote_count']) * C), axis=1)
    qualified = qualified.sort_values('wr', ascending=False).head(250)

    return qualified


# %%
