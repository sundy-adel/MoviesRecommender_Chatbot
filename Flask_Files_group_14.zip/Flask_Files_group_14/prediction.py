#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer


# In[2]:


import pickle

# Load the TF-IDF matrix from the file
with open("C:/Users/HUSSIEN/Downloads/tfidf.pkl", "rb") as file:
    tf = pickle.load(file)


# In[3]:


merged = pd.read_csv('C:/Users/HUSSIEN/Downloads/merged.csv')


# In[4]:


def overview(title):
    full_text_lower = title.lower()
    # Convert titles in DataFrame to lowercase and search for matching titles
    # Search for matching titles with at least 3 characters
    matching_titles = merged[merged['original_title'].apply(lambda title: len(title) >= 3 and title.lower() in full_text_lower)]
    # Collect matching titles in a list
    matching_titles_list = matching_titles['original_title'].tolist()
    for title in matching_titles_list:
        new_title = title
    index = merged[merged['title'] == new_title].index[0]
    overview = merged.at[index, 'overview_filtered']
    return overview


# In[5]:


# load random forest model
with open("C:/Users/HUSSIEN/Downloads/random_forest_model.pkl", 'rb') as f:
    model = pickle.load(f)


# In[6]:


def prediction(title):
    overview_list = [overview(title)]
    tfidf_data =pd.DataFrame(tf.transform(overview_list).toarray())
    # Get the column names
    column_names = tf.get_feature_names_out()

    # Assign the column names to the DataFrame
    tfidf_data.columns = column_names
    predictions = model.predict(tfidf_data)
    return predictions


# In[7]:


def movies_recommender(predictions):
    for i in range(9):
        if i == predictions:
            condition = merged['label'] ==i
            selected_rows = merged.loc[condition]
            selected = selected_rows[['original_title','genres','overview']].head(4)
            selected_rows_list = selected.to_dict(orient='records')
            selected_rows_list = selected.values.tolist()
            # list_of_lists = [[dictionary] for dictionary in selected_rows_list]
    return selected_rows_list


# In[ ]:




