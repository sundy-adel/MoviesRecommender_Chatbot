# Movies Recommender System 

The movie chatbot recommendation problem aims to build an interactive chatbot that can engage in a conversation with users and recommend movies based on their preferences

# Introduction

The chatbot is designed to comprehend the user's movie preferences, engage in pertinent conversations to gather essential details, and ultimately offer a curated selection of movie recommendations aligned with the user's specific genre preferences or based on a movie they prefer.


# Features

Feature 1 -> recommend according to genre 
Feature 2 -> recommend according to movie you prefer 


# Prerequisites

1. visual studio code 
2. ngrok 
3. scipy version :   1.7.3
4. scikit-learn version :  1.0.2
5. python version : 3.7.9
6. flask version : 2.2.2
7. Dialog Flow account 

# Installation

1. install vs code 
2. install python and make sure add path to environment variables in your system 
3. install flask --->>>> pip install Flask==2.2.2
4. install scipy ----->>> pip install scipy==1.7.3
5. install scikit-learn --->>> pip install scikit-learn==1.0.2
6. after installation make sure you put three files in the same folder 
    1. webhook.py 
    2. genre_prediction.py
    3. prediction.py 
7. befor running webhook.py --> we make sure pathes of 
    1. merged data set in genre_prediction.py is coreect 
    2. tfidf.pkl ,  random_forest_model.pkl and merged.csv in prediction.py is correct 
8. run webhook.py 
9. run ngrok using -->>>> ngrok.exe http 5000 (same port as flask) 
10. take forwarding link from ngrok like ( https://dcfb-156-192-193-58.ngrok-free.app ) and add flask route like (/webhook ) to become 
    (https://dcfb-156-192-193-58.ngrok-free.app/webhook)
11. in fullfilment in dialogflow take link and enable webhook and put it and save 


# code notebook 

we used some general library requirements like 
1. %pip install surprise
2. %pip install --upgrade surprise
3. nltk 
4. pandas 
5. numpy 
6. scikit-learn 
7. pickle 
8. matplotlib 
Note: we used jupyter extension in vs code for this project code 