import urllib
import json
import os
from flask import Flask , request , make_response , jsonify
from prediction import prediction , movies_recommender
from genre_prediction import build_chart
app = Flask(__name__)

@app.route('/webhook', methods = ['POST', 'GET'])
def webhook():
    if request.method == "POST":
        req = request.get_json(silent = True , force = True)
        res = req['queryResult']['parameters']
        res = processRequest(req)
        res = json.dumps(res , indent=4)
        r = make_response(res)
        r.headers['Content-Type'] = 'application/json'
        return r


def processRequest(req):
    query_response = req['queryResult']
    action_name = query_response.get('action')
    print(query_response)
    text = query_response.get('queryText', None)
    parameters = query_response.get('parameters', None)
    
    if action_name == 'generes':
        speech1 = list(build_chart(text)['title'].head(1))
        return {"fulfillmentText": speech1}
    elif action_name == 'movie_ac':
        recommended_movies = prediction(text)
        recommended = movies_recommender(recommended_movies)
        # Prepare the response to be sent back to Dialogflow
        recommended_json_str = "\n".join(json.dumps(item) for item in recommended)
        speech = "Recommended movies: \n" + recommended_json_str
        return {"fulfillmentText": speech}

if __name__ == '__main__':
    app.run(debug=True)
